/*
 * RELIC is an Efficient LIbrary for Cryptography
 * Copyright (c) 2012 RELIC Authors
 *
 * This file is part of RELIC. RELIC is legal property of its developers,
 * whose names are not listed here. Please refer to the COPYRIGHT file
 * for contact information.
 *
 * RELIC is free software; you can redistribute it and/or modify it under the
 * terms of the version 2.1 (or later) of the GNU Lesser General Public License
 * as published by the Free Software Foundation; or version 2.0 of the Apache
 * License as published by the Apache Software Foundation. See the LICENSE files
 * for more details.
 *
 * RELIC is distributed in the hope that it will be useful, but WITHOUT ANY
 * WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR
 * A PARTICULAR PURPOSE. See the LICENSE files for more details.
 *
 * You should have received a copy of the GNU Lesser General Public or the
 * Apache License along with RELIC. If not, see <https://www.gnu.org/licenses/>
 * or <https://www.apache.org/licenses/>.
 */

/**
 * @file
 *
 * Implementation of architecture-dependent routines.
 *
 * @ingroup arch
 */

#include "relic_types.h"

#include "lzcnt.inc"
#include "tzcnt.inc"

/**
 * Renames the inline assembly macro to a prettier name.
 */
#define asm					__asm__ volatile

#ifdef __ARM_ARCH_7M__
	/**
	 * Addresses of the registers.
	 */
 	/** @{ */
	volatile uint_t *DWT_CYCCNT = (uint_t *)0xE0001004;
	volatile uint_t *DWT_CONTROL = (uint_t *)0xE0001000;
	volatile uint_t *SCB_DEMCR = (uint_t *)0xE000EDFC;
	/** @} */
#endif

/*============================================================================*/
/* Public definitions                                                         */
/*============================================================================*/

void arch_init(void) {
#if TIMER == CYCLE

#if defined(__ARM_ARCH_6__) || defined(__ARM_ARCH_6J__) || defined(__ARM_ARCH_6K__) || defined(__ARM_ARCH_6Z__) || defined(__ARM_ARCH_6ZK__) || defined(__ARM_ARCH_6T2__)
	/*
	 * This relies on a Kernel module described in:
	 * http://blog.regehr.org/archives/794
	 */
	asm("mcr p15, 0, %0, c15, c12, 0" : : "r" (1));
#elif __ARM_ARCH_7A__
	/*
	 * This relies on a Kernel module described in:
	 * http://stackoverflow.com/questions/3247373/
	 * how-to-measure-program-execution-time-in-arm-cortex-a8-processor
	 */
	asm("mcr p15, 0, %0, c9, c12, 0" :: "r"(17));
	asm("mcr p15, 0, %0, c9, c12, 1" :: "r"(0x8000000f));
	asm("mcr p15, 0, %0, c9, c12, 3" :: "r"(0x8000000f));
#elif __ARM_ARCH_7M__
	*SCB_DEMCR = *SCB_DEMCR | 0x01000000;
	*DWT_CYCCNT = 0; // reset the counter
	*DWT_CONTROL = *DWT_CONTROL | 1 ; // enable the counter
#endif

#endif /* TIMER = CYCLE */
}

void arch_clean(void) {
}


ull_t arch_cycles(void) {
	uint_t value = 0;

#if TIMER == CYCLE

#if defined(__ARM_ARCH_6__) || defined(__ARM_ARCH_6J__) || defined(__ARM_ARCH_6K__) || defined(__ARM_ARCH_6Z__) || defined(__ARM_ARCH_6ZK__) || defined(__ARM_ARCH_6T2__)
	asm("mrc p15, 0, %0, c15, c12, 1" : "=r"(value));
#elif __ARM_ARCH_7A__
	asm("mrc p15, 0, %0, c9, c13, 0" : "=r"(value));
#elif __ARM_ARCH_7M__
	value = *DWT_CYCCNT;
#else
	#error "Unsupported ARM architecture. Cycle count implementation missing for this ARM version."
#endif

#endif /* TIMER = CYCLE */

	return value;
}

uint_t arch_lzcnt(uint_t x) {
#ifdef WSIZE == 32
	return lzcnt32_gcc_arm(x);
#elif WSIZE == 64
	return lzcnt64_gcc_arm(x);
#endif
}

uint_t arch_tzcnt(uint_t x) {
#ifdef WSIZE == 32
	return tzcnt32_gcc_arm(x);
#elif WSIZE == 64
	return tzcnt64_gcc_arm(x);
#endif
}
